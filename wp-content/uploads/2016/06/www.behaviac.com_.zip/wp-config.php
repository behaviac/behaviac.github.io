<?php
/**
 * WordPress基础配置文件。
 *
 * 这个文件被安装程序用于自动生成wp-config.php配置文件，
 * 您可以不使用网站，您需要手动复制这个文件，
 * 并重命名为“wp-config.php”，然后填入相关信息。
 *
 * 本文件包含以下配置选项：
 *
 * * MySQL设置
 * * 密钥
 * * 数据库表名前缀
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/zh-cn:%E7%BC%96%E8%BE%91_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL 设置 - 具体信息来自您正在使用的主机 ** //
/** WordPress数据库的名称 */
define('DB_NAME', 'www');

/** MySQL数据库用户名 */
define('DB_USER', 'root');

/** MySQL数据库密码 */
define('DB_PASSWORD', 'pjkui');

/** MySQL主机 */
define('DB_HOST', 'localhost');

/** 创建数据表时默认的文字编码 */
define('DB_CHARSET', 'utf8mb4');

/** 数据库整理类型。如不确定请勿更改 */
define('DB_COLLATE', '');

/**#@+
 * 身份认证密钥与盐。
 *
 * 修改为任意独一无二的字串！
 * 或者直接访问{@link https://api.wordpress.org/secret-key/1.1/salt/
 * WordPress.org密钥生成服务}
 * 任何修改都会导致所有cookies失效，所有用户将必须重新登录。
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Tg#2:+#bH?!9t)!;v@4(HM=6LrJ7S|x;|u;2^+}sa}`R1C&Db<z(<mB 4yd!^Cq^');
define('SECURE_AUTH_KEY',  '6gAc_@D:aTJDyU{hp~l*9:>j=grzB&F~Lt]UFSf]rMATsXd8-:kJH|PuL9`EjsYJ');
define('LOGGED_IN_KEY',    '3BA*C R#OC{UZ@q>@{`:O%1pcv DRMb+}5%%`x6{>k4QQ(:6=kxdg#JuObp2-,Gh');
define('NONCE_KEY',        ';cMYZ!~i*,h8aQZa%vB%A,*I7t Y;P2P-xdokRrN#omdf;4|DTG_MJ@l^dYt}NtH');
define('AUTH_SALT',        '(GXy(i-jGT=O<pB;o=slcx%U?bo>3|&lu.2,.LKgJQ,9KpnuZ.HQ--Vg?jj7!w^:');
define('SECURE_AUTH_SALT', '<Ig8I|%!q0xJZpy-ep6gG(~Nf#n0xpd%NOue-V=hU^X-z]BV#]Xt+v=MULYzns<A');
define('LOGGED_IN_SALT',   'eMp]c|0d^Cp=Dgq|*RZ:BF}KLU:P,Aq]1Pe:Qo{evu4}|e..A#ojM+qI%l+EP~]4');
define('NONCE_SALT',       'NTXm])mSB7+Y,H+{.I$e;E#CZ| Z0VEzMh:o,HQ.9-cQ:#^#~Nw`e2Hvh/M.%Y6t');

/**#@-*/

/**
 * WordPress数据表前缀。
 *
 * 如果您有在同一数据库内安装多个WordPress的需求，请为每个WordPress设置
 * 不同的数据表前缀。前缀名只能为数字、字母加下划线。
 */
$table_prefix  = 'www_';

/**
 * 开发者专用：WordPress调试模式。
 *
 * 将这个值改为true，WordPress将显示所有用于开发的提示。
 * 强烈建议插件开发者在开发环境中启用WP_DEBUG。
 *
 * 要获取其他能用于调试的信息，请访问Codex。
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/**
 * zh_CN本地化设置：启用ICP备案号显示
 *
 * 可在设置→常规中修改。
 * 如需禁用，请移除或注释掉本行。
 */
define('WP_ZH_CN_ICP_NUM', true);

/* 好了！请不要再继续编辑。请保存本文件。使用愉快！ */

/** WordPress目录的绝对路径。 */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** 设置WordPress变量和包含文件。 */
require_once(ABSPATH . 'wp-settings.php');

define('RELOCATE',true);

define("FS_METHOD","direct");

define("FS_CHMOD_DIR", 0777);

define("FS_CHMOD_FILE", 0777);
