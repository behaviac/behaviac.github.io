# Allow SSH tab completion for mosh hostnames
compdef mosh=ssh
